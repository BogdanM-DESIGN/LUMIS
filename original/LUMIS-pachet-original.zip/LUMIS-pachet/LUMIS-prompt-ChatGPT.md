# Prompt pentru ChatGPT: site-ul LUMIS

> Copiază tot textul de mai jos în ChatGPT. Atașează și imaginile din arhiva `LUMIS-pachet.zip` (folderul `img/`) și cele două fișiere de cod, `index-simplu.html` și `index-complet.html`.

---

## 1. Rolul tău și ce vreau

Ești designer și dezvoltator front-end senior, cu experiență în site-uri de modă și de design (Zara, COS, Arket, Apple). Construiește site-ul **LUMIS**, un magazin online mic de lămpi decorative printate 3D.

Vreau un site **real, bine codat, care să nu arate a prototip**: curat, aerisit, fluid, rapid. Mai jos sunt brandul, produsele, direcția vizuală, structura paginii, ce îmi place, ce NU vreau și cerințele tehnice. Respectă-le exact. Unde lipsește o informație (prețuri, date de firmă), pune o variabilă ușor de completat, nu inventa.

## 2. Brandul

- **Nume:** LUMIS. **Îmi place mult numele, logoul și imaginea de prezentare cu lămpile în spate. Păstrează-le.**
- **Logo:** cuvântul „LUMIS" scris cu un font Didone, cu contrast mare (Google Fonts: **Bodoni Moda**, 400), spațiere între litere ~0,06–0,14em. În meniu e mic (~21px). În prezentare e uriaș (~19–21vw), alb, peste imaginea cu lămpile.
- **Mesaj principal:** „Amintirile tale, în lumină."
- **Descriere scurtă:** „Lămpi printate 3D · asamblate manual în România."
- **Ton:** calm, scurt, elegant. Fraze simple, fără superlative.

## 3. Produsele (date reale din macheta mea)

Toate lămpile au un abajur interschimbabil care se prinde în soclu cu o răsucire.

**Forme de abajur (4 modele):**
| Model | Descriere |
|---|---|
| Litofanie | Fotografia clientului, vizibilă doar când lampa e aprinsă. Stinsă pare un relief alb, aprinsă apare fotografia, cu umbre și detalii fine. Produs personalizat. |
| Wave | Șase valuri fluide, rotite discret de jos până sus. |
| Twist | Nervuri ascuțite într-o spirală de 180°. |
| Ribbed | Siluetă de vază cu 36 de nervuri fine. |

**Socluri (3):**
- **Galet:** bombat și moale, cel mai cald.
- **Monolit:** cilindru curat, cu umăr rotunjit.
- **Con:** mai lat la bază, foarte stabil.

**Culori soclu:** Alb mat `#E2DFD8` · Negru mat `#222120` · Grafit `#48484A` · Champagne `#CDB68C`

**Inel între soclu și abajur:** Champagne (ca un inel de metal) sau Linie de lumină (albă, luminoasă).

**Specificații:**
- Ø128 mm la bază, aproximativ 20 cm înălțime;
- LED alb cald 5 V / 3 W, alimentare USB, joasă tensiune;
- difuzor peste LED, deci sursa de lumină nu se vede;
- greutate în bază; cablul iese pe sub soclu, prin spate.

**Procesul pentru litofanie:**
1. Clientul încarcă fotografia și alege soclul, culoarea și inelul.
2. Noi retușăm poza și îi trimitem pe e-mail previzualizarea lămpii aprinse. Printăm doar după ce o aprobă.
3. Lampa ajunge asamblată, testată, ambalată ca un cadou, cu cablu USB și instrucțiuni.

**Prețuri:** încă nestabilite. Pune-le într-un singur obiect de date (`products.json` sau un array JS), cu valori ușor de schimbat. Nu afișa paranteze de tipul „[PREȚ]".

## 4. Direcția vizuală

### Tipografie și culori în stil Zara
- **Text:** font sans neutru, tip Helvetica. Google Fonts: **Instrument Sans** 400/500/600.
- **Mărimi:**
  - text de bază 13px;
  - etichete, meniu, nume de produse și prețuri: 11px, MAJUSCULE, spațiere 0,12–0,16em, greutate 500;
  - titluri de secțiune: 18–24px, MAJUSCULE, spațiere ~0,08em, greutate 400.
- **Culori:**
  - text negru `#111111` pe fundal alb-cald `#F7F7F6`;
  - text secundar gri `#6B6B6B` (contrast AA);
  - un singur accent cald, `#E9B877` (culoarea luminii lămpii), folosit doar pentru detalii legate de lumină: punct luminos, bara de progres.
- Fără gradiente colorate, fără emoji, fără umbre exagerate.

### Mult spațiu alb
- Margini laterale: `clamp(20px, 6vw, 112px)`.
- Spațiu între secțiuni: `clamp(120px, 16vw, 260px)`.
- Spațiu generos între produse: rânduri ~56–96px, coloane ~16–36px.
- Pagina trebuie să respire. Nu înghesui nimic.

### Sticlă argintie / albă, ca „Liquid Glass" pe iPhone, dar discret
- **Meniu:** o capsulă de sticlă mată care plutește sus, centrată, lățime maximă ~720px.
  - Fundal `linear-gradient(160deg, rgba(255,255,255,.86), rgba(255,255,255,.62))`, plus `backdrop-filter: blur(16px) saturate(1.5)`.
  - Margine 1px albă semitransparentă, reflex interior `inset 1px 1px 0 rgba(255,255,255,.85)` și umbră foarte fină.
  - Conține: logoul LUMIS în stânga, apoi linkul „MODELE" și butonul negru „COȘ" cu numărul de produse.
- **Etichetele de pe poze și butonul „+":** tot din sticlă.
- **„Picătura de apă":**
  - în controalele segmentate (soclu, culoare, inel), opțiunea aleasă e marcată de o picătură de sticlă albă care alunecă la noua opțiune și se întinde elastic pe drum (Web Animations API, ~550ms, easing cu revenire elastică);
  - la „Adaugă în coș", o picătură de sticlă zboară în arc de la buton la coș, apoi coșul face un efect de „jeleu" (scale 1,12/0,9 → 1);
  - sub meniu apare o notificare neagră, ca Dynamic Island pe iPhone, care crește elastic din centru, de exemplu „RIBBED · ADĂUGATĂ ÎN COȘ", și dispare după ~2,5s.
- **Fără efecte grele:** fără refracție SVG pe suprafețe mari, fără `backdrop-filter` pe zone mari care se mișcă.

## 5. Structura paginii principale (scurtă: patru părți)

### 1) Prezentarea, cu logoul (îmi place exact așa, păstreaz-o)
- Imagine pe toată lățimea: `pano.jpg`, cu patru lămpi aprinse (Twist, Litofanie, Wave, Ribbed) pe o comodă lungă din stejar, seara, cu perete de tencuială caldă.
- Înălțime: `clamp(560px, 62vw, 100svh)`, `object-fit: cover`, ancorată jos. Pe telefon ~82svh.
- Peste zona de perete: logoul **LUMIS** uriaș, alb (~94% opacitate), centrat, cu un degrade fin întunecat sus și jos pentru lizibilitate.
- În stânga jos, text mic, alb, cu majuscule: „AMINTIRILE TALE, ÎN LUMINĂ" și dedesubt „LĂMPI PRINTATE 3D · ASAMBLATE MANUAL ÎN ROMÂNIA".
- În dreapta jos: buton alb, rotunjit, „VEZI MODELELE", care derulează lin la produse.
- **La deschiderea paginii, lămpile trebuie să se aprindă sincronizat, nu doar să se lumineze toată poza.** Varianta recomandată:
  - la prima afișare poza apare ușor estompată (seara);
  - apoi lămpile se „aprind" pe rând, de la stânga la dreapta, la ~120ms una de alta: o mască radială moale pe fiecare lampă dezvăluie varianta aprinsă;
  - logoul apare odată cu ultima lampă.
  - Dacă nu ai și varianta stinsă a panoramei, fă doar o intrare scurtă și elegantă: logoul apare (fade 1,2s), fără efect de luminozitate pe toată poza.

### 2–3) Camera: ziua → seara → lampa se aprinde (secțiune fixă la derulare)
- Deasupra, un titlu mic centrat, cu mult spațiu în jur: „ACEEAȘI CAMERĂ, ZIUA ȘI SEARA".
- Secțiunea are ~230vh înălțime. În interior, un cadru `position: sticky; top: 0; height: 100svh`, cu margine albă în jurul imaginii (spațiu pentru meniu sus).
- **Trei imagini cu exact același cadru:**
  - `hero-zi.jpg`: ziua, lampa stinsă, soare prin fereastră;
  - `hero-off.jpg`: seara, lampa stinsă;
  - `hero.jpg`: seara, lampa aprinsă.
- **Sincronizarea, foarte important:**
  - progresul derulării `p` merge de la 0 la 1;
  - între p = 0 și ~0,45, imaginea trece gradual de la zi la „seara, stinsă" (legat direct de derulare: lumina zilei scade);
  - la p ≥ 0,55, lampa **se aprinde ca la un întrerupător**: imaginea aprinsă apare într-o animație de timp, nu legată de derulare (~120ms până la ~85%, apoi ~400ms până la 100%, ease-out);
  - **în exact același moment**, textul se schimbă din „ZIUA · Un obiect de design, chiar și stinsă" în „SEARA · Aprinsă, luminează camera";
  - folosește histerezis (se stinge doar când p scade sub ~0,5), ca să nu pâlpâie;
  - textul stă într-un mic card de sticlă, în stânga jos.
- Animează doar `opacity` și `transform`. Scroll-ul se citește cu `requestAnimationFrame`.

### 4) Modelele puse la vânzare
- Titlu mic „MODELE" în stânga și o frază scurtă în dreapta.
- Grilă cu 4 coloane pe desktop, 2 pe tabletă, 1 pe telefon (pozele mari).
- **Lampa trebuie să fie în prim-plan:** încadrare strânsă pe lampă, ca ea să ocupe cea mai mare parte a imaginii (de exemplu `object-position` și un `scale(1.15–1.25)` pe imagine).
- Fiecare produs are:
  - poza lămpii aprinse; la hover, trecere lină (~0,8s) la aceeași cameră ziua, cu lampa stinsă;
  - un buton rotund de sticlă „+" în colț, care adaugă în coș cu animația picăturii;
  - dedesubt, pe un rând, numele și prețul (11px, majuscule), apoi o descriere de o linie, gri.
- Click pe produs → se deschide **pagina de produs** (secțiunea 6).

### Subsol minimal
- O linie fină sus și mult spațiu.
- Pe un rând, text de 10,5px cu majuscule: „© 2026 Lumis", linkurile „Livrare și retur · Termeni · Confidențialitate · ANPC – SAL" și contactul.

## 6. Pagina de produs (deschisă peste pagină, ca o foaie de sticlă)
- Folosește `<dialog>` cu `showModal()`, ca să ai focus și tasta Esc corecte. Pe desktop e un panou mare; pe telefon, o foaie care urcă de jos.
- **Galerie:** poza aprinsă și poza ziua (stinsă), cu miniaturi sau glisare.
- **Detalii:** nume, preț, descriere, apoi opțiunile cu picătura de sticlă care alunecă:
  - soclu (Galet / Monolit / Con);
  - culoare (4 cercuri cu culorile de mai sus);
  - inel (Champagne / Linie de lumină);
  - cantitate.
- **Doar pentru Litofanie:**
  - câmp de încărcare a fotografiei;
  - o **simulare în browser** cu `<canvas>`: luminanța pozei mapată pe o paletă caldă (maro închis → chihlimbar → crem), umbrire cilindrică (mai întunecat la margini), benzi mai închise sus și jos, ca ramă;
  - textul „Simulare orientativă. Previzualizarea reală o primești pe e-mail.";
  - poza nu se trimite nicăieri.
- Buton negru „ADAUGĂ ÎN COȘ".
- Acordeoane scurte, cu deschidere lină: Dimensiuni, Lumină, Livrare (din datele de la punctul 3).

## 7. Coșul
- Panou lateral din sticlă albă, care alunecă din dreapta (`<dialog>`).
- Pe fiecare linie: miniatura, numele, opțiunile alese, cantitatea +/−, eliminare.
- Subtotal și buton „FINALIZEAZĂ COMANDA", pregătit pentru integrarea plății: Stripe, Shopify sau WooCommerce, le alegem ulterior.
- Coșul se păstrează în `localStorage`, cu try/catch.

## 8. Ce NU vreau (feedback de până acum)
- **Fără** secțiunea „ce e în interior" / secțiune prin soclu. Clienții vor să vadă lampa, nu componentele.
- **Fără** comutator Zi/Seară în meniu. E inutil.
- **Fără** pagină încărcată: fără bandă de text care rulează, fără titluri cu sclipire argintie, fără carduri care se înclină, fără multe secțiuni una după alta. Comparatorul, configuratorul complet și întrebările frecvente stau în pagina de produs sau în pagini separate, nu pe prima pagină.
- **Fără** aspect de prototip: fără paranteze „[PREȚ]", fără etichete „prototip", fără linkuri moarte.
- **Fără** aprinderea nesincronizată a lămpilor (o simplă suprapunere între două poze). Lumina trebuie să pară reală.

## 9. Cerințe tehnice
- **Cod curat și organizat:**
  - HTML semantic;
  - CSS cu variabile (design tokens) și clase clare;
  - JavaScript modular, fără biblioteci grele;
  - produsele generate din date (un singur loc pentru nume, prețuri, imagini, opțiuni).
- **Imagini:**
  - WebP cu `srcset`/`sizes` (lățimi 640, 1280, 1920, 2400) și `width`/`height` setate, ca să nu sară conținutul;
  - prezentarea se încarcă prioritar (`fetchpriority="high"`), restul cu `loading="lazy"` și `decoding="async"`.
- **Performanță:**
  - 60 fps la derulare;
  - animații doar pe `transform`/`opacity`;
  - fără `backdrop-filter` pe zone mari în mișcare;
  - fonturi cu `display=swap`.
- **Accesibilitate:**
  - contrast AA, focus vizibil, `aria-label` pe butoanele doar cu iconiță;
  - texte alternative descriptive pe toate pozele;
  - `prefers-reduced-motion`: fără animații, schimbări instant.
- **Responsive:** fără derulare pe orizontală la 360–400px; margini sigure pentru iPhone (`env(safe-area-inset-*)`).
- **Livrabil:**
  - structura completă de fișiere (`index.html`, `css/`, `js/`, `data/products.json`, `img/`) și tot codul;
  - instrucțiuni de publicare (de exemplu Netlify sau Vercel);
  - propunere de pas următor pentru plăți: Shopify sau WooCommerce + Stripe, cu avantaje și dezavantaje.

## 10. Partea legală (România), de pregătit
- Pagini: Termeni și condiții, Confidențialitate (GDPR, cu atenție la fotografiile clienților: le folosim doar pentru comandă și nu le publicăm fără acord) și Livrare și retur.
- Produsele personalizate (litofania) pot fi exceptate de la dreptul de retragere. **De verificat cu un jurist.**
- Link ANPC – SAL: https://anpc.ro/ce-este-sal/. Platforma europeană SOL (ODR) a fost închisă în iulie 2025, deci verifică ce se cere acum.
- Datele firmei (denumire, CUI, adresă, e-mail, telefon) le completez eu. Lasă variabile.

## 11. Imaginile atașate (randări 3D realiste, aceeași lumină și aceleași materiale)
| Fișier | Ce arată | Unde se folosește |
|---|---|---|
| `pano.jpg` (2400×1030) | Cele 4 lămpi aprinse pe comoda lungă de stejar, seara | Prezentarea, cu logoul |
| `hero-zi.jpg` (1920×1080) | Litofania stinsă, ziua, soare prin fereastră | Camera, pasul 1 |
| `hero-off.jpg` (1920×1080) | Aceeași cameră seara, lampa stinsă | Camera, pasul 2 |
| `hero.jpg` (1920×1080) | Aceeași cameră seara, lampa aprinsă | Camera, pasul 3 |
| `litofanie.jpg` / `litofanie-zi.jpg` | Litofanie pe Galet alb, inel champagne, seara / ziua, același cadru | Produs |
| `wave.jpg` / `wave-zi.jpg` | Wave pe Galet alb, noptieră din nuc, seara / ziua | Produs |
| `twist.jpg` / `twist-zi.jpg` | Twist pe Monolit negru, inel de lumină, seara / ziua | Produs |
| `ribbed.jpg` / `ribbed-zi.jpg` | Ribbed pe Monolit negru, inel de lumină, seara / ziua | Produs |
| `galet.jpg`, `monolit.jpg`, `con.jpg` | Cele 3 socluri, ziua, aceeași cameră | Pagina de produs (soclu) |
| `detaliu.jpg` | Ribbed stinsă pe Con grafit, lumină de după-amiază | Galerie produs |
| `litho-mostra.jpg` | Mostră alb-negru pentru simularea litofaniei | Simularea din pagina de produs |

Perechile „seara / ziua" au exact același cadru, deci trecerea dintre ele pare doar o schimbare de lumină. Imaginile sunt randări, nu fotografii. Le voi înlocui ulterior cu fotografii reale ale produselor.

## 12. Cod de referință (atașat, în aceeași arhivă)
- `index-simplu.html`: ultima versiune aprobată ca format: prezentare + cameră + modele + subsol, cu meniul din sticlă și picătura care zboară în coș. **Pornește de la ea**, dar rescrie-o curat și corectează aprinderea lămpii.
- `index-complet.html`: versiunea mai bogată (configurator cu picătura care alunecă, comparator stinsă/aprinsă, simularea litofaniei pe canvas). Ia de aici doar ce intră în **pagina de produs**, nu pe prima pagină.

---
Începe prin a-mi confirma pe scurt structura și tehnologiile alese, apoi livrează codul complet.
